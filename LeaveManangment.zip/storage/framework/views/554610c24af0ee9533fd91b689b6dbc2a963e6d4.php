<?php $__env->startSection('title','Leave Manange - Forgot-Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="page-content--bge5"
        style="background-image: url('img/bg.png'); background-repeat: no-repeat; background-size: cover;">
        <div class="container">
            <div class="login-wrap">
                <div class="login-content">
                    <div class="login-logo">
                        <h1> FORGOT-PASSWORD PAGE </h1>
                        

                    </div>
                    <div class="login-form">
                        <form action="<?php echo e(url('/forgot-password')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input class="au-input au-input--full" type="email" name="email" placeholder="Email"
                                    value="<?php echo e(old('email')); ?>">
                            </div>
                            <div class="form-group">
                                <label>New Password</label>
                                <input class="au-input au-input--full" type="password" name="password"
                                    placeholder="Password">
                            </div>
                            <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">Send Email</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<script src="<?php echo e(asset('dashboard/js/sweetalert.all.js')); ?>"></script>
<?php if(Session::has('flash_alert_errors')): ?>
<script>
    Swal.fire({
        type: 'error',
        title: '<?php echo Session::get('flash_alert_errors'); ?>',

        })
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('login.master_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Leave MI\LeaveManangment\resources\views/login/forgot-password.blade.php ENDPATH**/ ?>