<?php $__env->startSection('title','Leave Manage - Sign_In'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="page-content--bge5"
        style="background-image: url('img/bg.png'); background-repeat: no-repeat; background-size: cover;">
        <div class="container">
            <div class="login-wrap">
                <div class="login-content">
                    <div class="login-logo">
                        <h1> SIGN-IN PAGE </h1>
                        

                    </div>

                    <div class="login-form">
                        <form action="<?php echo e(url('/')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>E-mail</label>
                                <input class="au-input au-input--full" type="email" name="email" id="email"
                                    placeholder="E-mail" value="<?php echo e(old('email')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="au-input au-input--full" type="password" name="password" id="password"
                                    placeholder="Password" required>
                            </div>
                            <div class="login-checkbox float-right">
                                <label>
                                    <a href="<?php echo e(url('forgot-password')); ?>">Forgotten Password?</a>
                                </label>
                            </div>
                            <button class="au-btn au-btn--block au-btn--green m-b-15" type="submit">sign in</button>
                        </form>
                        <div class="register-link">
                            <p>
                                Don't you have account?
                                <a href="<?php echo e(url('/register')); ?>">Sign Up Here</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<script src="<?php echo e(asset('dashboard/js/sweetalert.all.js')); ?>"></script>
<?php if(Session::has('flash_alert_errors')): ?>
<script>
    Swal.fire({
        type: 'error',
        title: '<?php echo Session::get('flash_alert_errors'); ?>',

        })
</script>
<?php elseif(Session::has('flash_confirm_success')): ?>
<script>
    Swal.fire({
        type: 'success',
        title: 'Account activated',
        text: '<?php echo Session::get('flash_confirm_success'); ?>',

        })
</script>
<?php elseif(Session::has('flash_forgot_success')): ?>
<script>
    Swal.fire({
        type: 'success',
        title: 'Create password successfully',
        text: '<?php echo Session::get('flash_forgot_success'); ?>',

        })
</script>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('login.master_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project Leave MI\LeaveManangment\resources\views/login/login.blade.php ENDPATH**/ ?>